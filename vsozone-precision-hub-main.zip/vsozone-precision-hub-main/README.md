# VSOZONE Elevate

MASTER WEBSITE PROMPT — VSOZONE TECHNOLOGIES
Create a premium, modern, highly professional, conversion-focused corporate + product-commerce website for:
VSOZONE Technologies
Official business name: V.S. Ozone Technologies
Tagline: “Where Accuracy Meets Quality”
The website should position VSOZONE Technologies as a trusted Indian engineering, weighing, automation, security and technology solutions company, not as a small local shop.
1. DESIGN REFERENCE
Use Reliance Digital only as a UX / information-architecture reference.
Reference:
https://www.reliancedigital.in/
Study the reference website for concepts such as:
Large, prominent search
Clear category navigation
Product discovery
Category-based browsing
Promotional hero banners
Product cards
Product detail pages
Service/support sections
Store/location discovery
Strong calls-to-action
Clean footer architecture
Responsive desktop/mobile experience
IMPORTANT:
DO NOT COPY Reliance Digital's:
Colour palette
Logo style
Branding
Typography
Exact layouts
Images
Text
UI elements pixel-for-pixel
The website must have its own premium VSOZONE identity.
2. BRAND COLOUR SYSTEM
Use the uploaded VSOZONE logo as the primary brand reference.
Extract the visual colour language from the logo:
Primary colours
Deep emerald / forest green
Dark teal green
Metallic gold
Warm golden yellow
Supporting colours
Off-white
Soft ivory
Very light neutral grey
Charcoal / deep green-black
Do NOT introduce bright blue, Reliance-style blue, red, purple or unrelated brand colours.
The overall appearance should feel:
Premium + Industrial + Reliable + Technological + Indian + Established
Use gold primarily for:
Important highlights
Premium accents
CTA hover states
Icons
Small separators
Numbers/statistics
Selected navigation elements
Do NOT overuse gold.
Use deep green/teal for:
Primary buttons
Navigation
headings
major brand elements
important backgrounds
Use off-white/light neutral backgrounds for most content.
3. OVERALL VISUAL DIRECTION
Imagine a combination of:
Premium industrial manufacturer + modern technology company + sophisticated product marketplace.
The website should immediately communicate:
“This is an established engineering and technology company that can handle everything from precision jewellery scales to massive industrial weighbridges.”
Use:
Large typography
Generous whitespace
High-quality product photography
Subtle glass/metal textures
Soft shadows
Rounded but professional cards
Premium micro-interactions
Smooth scrolling
Elegant hover effects
Subtle gold highlights
Technical specification sections
High-quality industrial imagery
Clean iconography
Avoid:
Cheap-looking gradients
Excessive animations
Cartoon illustrations
Excessive rounded corners
Generic startup templates
Cluttered layouts
Excessive gold
Fake testimonials
Fake statistics
Fake certifications
Fake awards
4. WEBSITE STRUCTURE
Create the following major sections/pages:
MAIN NAVIGATION
Logo on the left:
VSOZONE Technologies
Navigation:
Home
Products
Industries
Solutions
Services
About Us
Resources
Contact
Right side:
Search
WhatsApp
Get a Quote
On mobile:
Logo
Search
WhatsApp
Hamburger menu
Make the navigation sticky while scrolling.
5. HERO SECTION
Create a cinematic premium hero section.
Headline:
“Precision That Powers Business.”
Supporting text:
“Advanced weighing, automation, security and business technology solutions engineered for accuracy, reliability and long-term performance.”
Primary CTA:
Explore Products
Secondary CTA:
Get a Quote
Third smaller action:
Talk to an Expert
Hero visual:
Create a sophisticated industrial composition featuring:
Industrial weighbridge
High-precision weighing machine
Jewellery weighing scale
Cash counting machine
CCTV/security technology
Modern industrial environment
Do NOT make it look like a collage.
Instead create a polished visual composition where the products appear naturally within an industrial technology environment.
Add subtle animated technical lines/grid elements.
Include a small premium badge:
20+ Years of Engineering Experience
Only display this if the business confirms the exact number.
6. TRUST STRIP
Immediately below the hero:
Create a horizontal trust section with:
20+ Years of Experience
Engineering & Technology
Precision Solutions
Commercial & Industrial
Complete Support
Installation • AMC • Repair
Regional Service Network
Karnataka & Beyond
Do not fabricate numerical claims beyond information supplied by the company.
7. PRODUCTS SECTION
Heading:
“Technology Built for Every Scale.”
Subheading:
“From precision jewellery weighing to heavy-duty industrial weighing infrastructure, explore our complete range of technology solutions.”
Create premium category cards.
CATEGORY 01
Weighing Machines
Show:
Jewellery Weighing Machines
Candy Scales
Table Top Scales
Personal & Baby Scales
Roller Platform Scales
Platform Scales
Heavy Platform Scales
CTA:
Explore Weighing Solutions →
CATEGORY 02
Weighbridges
Show:
Electronic Weighbridges
Heavy-Duty Weighbridges
Industrial Weighing Systems
High-Capacity Weighing Infrastructure
Mention:
Capacity range: 10 Tons – 500 Tons
Only display this as a company-provided specification.
CTA:
Explore Weighbridges →
CATEGORY 03
Cash Counting & Billing
Show:
Cash Counting Machines
Currency Counting Solutions
Fake Note Detection
Billing Machines
POS Solutions
CTA:
Explore Cash & Billing →
CATEGORY 04
Security Solutions
Show:
CCTV Cameras
Surveillance Systems
Safety Lockers
Security Systems
CTA:
Explore Security →
CATEGORY 05
Automation & Services
Show:
Installation
Commissioning
Automation
AMC
Maintenance
Repair
Spare Parts
CTA:
Explore Services →
8. PRODUCT CATEGORY GRID
Create a highly polished marketplace-style section inspired by the usability of Reliance Digital.
Title:
“Explore Our Complete Range”
Create visual product-category tiles.
Each card should include:
Product image
Product name
Short description
Application
Capacity/specification where applicable
“View Details”
“Get Quote”
Categories:
Jewellery Model — VTE
300 g × 0.01 g
600 g × 0.01 g
Candy Scale
5 kg – 20 kg
Table Top Scale
10 kg – 35 kg
Personal + Baby Scale
100 kg – 150 kg
Roller Platform
200 kg – 500 kg
Platform — CH
200 kg – 300 kg
Platform — SS
100 kg – 200 kg
Heavy Platform — CH
1000 kg – 2000 kg
Make the cards look premium and technical.
9. PRODUCT DETAIL PAGE
Every major product should have its own product-detail layout.
Structure:
Product image gallery
Product name
Short professional description
Capacity
Accuracy
Construction/material
Display
Applications
Key features
Technical specifications
Industries served
Installation availability
Service availability
CTA:
Request a Quote
Secondary:
WhatsApp Us
Third:
Talk to an Engineer
Do NOT invent specifications that have not been provided.
Use:
“Contact us for detailed specifications”
where information is unavailable.
10. FEATURED INDUSTRIAL SECTION
Create a dramatic full-width section:
“Engineered for Industries That Cannot Afford Inaccuracy.”
Visual:
Large industrial weighbridge / factory environment.
Overlay cards:
Manufacturing
Precision weighing for industrial operations.
Logistics & Transport
Reliable vehicle and material weighing.
Retail
Accurate commercial weighing and billing.
Jewellery
High-precision weighing solutions.
Agriculture
Robust weighing solutions for agricultural applications.
Warehousing
Reliable weighing infrastructure.
Banking & Cash Operations
Cash counting and security solutions.
Commercial Businesses
Integrated weighing, billing and security technology.
11. WHY VSOZONE
Create a premium section titled:
“Why Businesses Choose VSOZONE”
Use 6 elegant feature cards:
Precision
Solutions designed around accurate measurement.
Reliability
Equipment designed for dependable everyday operation.
Engineering
Technology backed by practical engineering expertise.
Complete Solutions
Products, installation, commissioning and support.
Service
AMC, maintenance, repairs and spare parts.
Long-Term Partnership
Support beyond the initial purchase.
Do not make unsupported claims such as “India's No.1” or “best in India.”
12. SERVICE ECOSYSTEM
Create a section:
“More Than Products. Complete Support.”
Use a horizontal journey:
Consultation → Selection → Installation → Commissioning → Training → AMC → Maintenance → Repair
Services:
Installation
Commissioning
Calibration support
Automation
AMC
Maintenance
Repair
Spare Parts
Primary CTA:
Book a Service
Secondary:
Talk to a Service Engineer
13. INDUSTRIES WE SERVE
Create an interactive industry section.
Industries:
Jewellery
Manufacturing
Logistics
Transportation
Agriculture
Retail
Warehousing
Banking
Commercial Businesses
Construction
Industrial Operations
When the user hovers over an industry, change the background image and show a short description.
14. REGIONAL SERVICE NETWORK
Create a premium India/Karnataka map section.
Title:
“Serving Businesses Across South & West India”
Highlight:
Karnataka
Kalaburagi
Bidar
Yadgir
Vijayapura
Bagalkot
Ballari
Raichur
Mangaluru
Karwar
Beyond Karnataka
Goa
Maharashtra
Do not show exact service coverage as guaranteed unless confirmed by the company.
CTA:
Find Service Near You
15. ABOUT VSOZONE
Create a sophisticated company story.
Headline:
“Two Decades of Building Trust Through Technology.”
Content:
“V.S. Ozone Technologies is an Indian engineering and technology company based in Kalaburagi, Karnataka, serving businesses with weighing, cash-handling, security, billing and automation solutions.”
Mention:
Established in 2002
Engineering and manufacturing orientation
Industrial and commercial weighing
Weighbridges
Cash handling
Billing
Security
Installation
AMC
Maintenance
Spare parts
Use the company motto:
“Where Accuracy Meets Quality”
16. FOUNDER / LEADERSHIP SECTION
Create a premium founder profile section using the uploaded professional photograph.
Display the photograph professionally with a subtle dark-green/gold frame.
Name:
Veeresh Vishwanth
Title:
Founder & Visionary Leader
Short profile:
“Veeresh Vishwanth represents the leadership vision behind VSOZONE Technologies, with a focus on building a trusted technology and engineering business around accuracy, dependable products and long-term customer relationships.”
Add:
“Under this vision, VSOZONE focuses on delivering practical technology solutions across weighing, industrial infrastructure, cash handling, security and business automation.”
Use the uploaded portrait exactly as the reference image.
Do not alter facial identity.
Do not invent educational qualifications, awards, degrees, positions or personal achievements.
IMPORTANT:
If official company records identify a different legal proprietor/founder, clearly distinguish the brand leadership profile from the legal registration information rather than silently changing facts.
17. FOUNDER QUOTE
Create an elegant quote card:
“Our goal is simple — deliver accuracy, quality and dependable technology that businesses can trust.”
Attribute:
Veeresh Vishwanth
VSOZONE Technologies
Treat this as a brand statement, not a verified historical quotation unless the company confirms it.
18. COMPANY TIMELINE
Create a visually impressive horizontal timeline.
2002
Company established.
Growth
Expansion into weighing and industrial solutions.
Technology Expansion
Cash counting, billing and security solutions.
Service Expansion
Installation, AMC, maintenance and spare-parts support.
Today
A broader engineering and technology solutions portfolio.
Do not fabricate exact milestone years.
19. FUTURE TECHNOLOGY / R&D
If the company confirms these initiatives, create a premium futuristic section:
“Engineering the Next Generation.”
Show:
Electric Vehicle technology
LFP battery technology
Energy storage
Automation
Industrial technology
Present these as:
R&D / Emerging Technology
Do NOT present these as commercially available products unless confirmed.
20. CUSTOMER ENQUIRY SYSTEM
Make conversion extremely easy.
Floating WhatsApp button:
WhatsApp Us
Floating call button on mobile:
Call Now
Every product card should have:
Get Quote
Create a beautiful enquiry modal.
Fields:
Name
Company
Phone Number
Location
Product / Requirement
Message
Button:
Send Enquiry
Also provide:
Call / WhatsApp: 9972607605
21. WHATSAPP AUTOMATION MESSAGE
Use this as the website enquiry confirmation / WhatsApp communication:
“Welcome to VSOZONE Technologies!
Thank you for contacting us.
We specialize in:
• Electronic Weighbridges
• Electronic Weighing Machines
• Jewellery Weighing Machines
• Cash Counting & Billing Machines
• Safety Lockers & Security Systems
• Installation, Commissioning & Automation
• AMC, Maintenance & Repair Services
• Spare Parts
Please share:
Your Name
Location
Your Requirement
Our team will contact you shortly with the best solution.”
22. CONTACT PAGE
Create a premium contact page.
VSOZONE Technologies
Plot No. 199, Ground Floor, Venkatesh,
Zafarabad Shaik Roza,
Opp. Agriculture College, Aland Road,
Kalaburagi, Karnataka – 585103
Phone / WhatsApp
9972607605
Include:
Google Maps integration placeholder
WhatsApp CTA
Call CTA
Enquiry form
Business hours placeholder
Email placeholder
Do not invent an email address.
23. FOOTER
Create a large premium footer.
Columns:
Products
Weighing Machines
Weighbridges
Cash Counting Machines
Billing Machines
CCTV
Safety Lockers
Solutions
Industrial Weighing
Commercial Weighing
Security
Automation
Business Solutions
Services
Installation
Commissioning
AMC
Maintenance
Repair
Spare Parts
Company
About Us
Founder
Industries
Service Network
Contact
Connect
WhatsApp
Phone
Social Media
Bottom:
© VSOZONE Technologies. All Rights Reserved.
“Where Accuracy Meets Quality”
24. SEARCH EXPERIENCE
Create a powerful search bar.
Placeholder:
“Search weighing machines, weighbridges, CCTV, cash counters...”
Search results should be categorized:
Products
Solutions
Services
Industries
Add autocomplete suggestions.
25. PREMIUM MICRO-INTERACTIONS
Use subtle animations:
Product cards gently lift on hover
Gold accent line appears on hover
Images slightly zoom
Navigation transitions smoothly
Numbers animate when entering viewport
Sections reveal with subtle fade/slide
CTA buttons have sophisticated hover animation
Interactive industry cards
Smooth page transitions
Avoid excessive animations.
The site should remain fast.
26. MOBILE EXPERIENCE
The website must be designed mobile-first.
On mobile:
Sticky header
One-tap WhatsApp
One-tap calling
Swipeable product cards
Horizontal category scrolling
Large CTA buttons
Optimized images
Fast loading
Easy enquiry form
Bottom mobile navigation:
Home | Products | WhatsApp | Call | Contact
27. SEO
Create SEO-friendly page titles and metadata.
Primary keywords to naturally target:
Weighing Machine Manufacturer in Karnataka
Weighbridge Manufacturer
Electronic Weighing Machines
Jewellery Weighing Machine
Industrial Weighing Machine
Platform Weighing Machine
Cash Counting Machine
Billing Machine
CCTV Solutions
Safety Lockers
Weighbridge Services
Weighing Machine Service
Kalaburagi Weighing Machine
Weighbridge in Karnataka
Do NOT keyword-stuff.
28. PERFORMANCE
Prioritize:
Fast loading
WebP/AVIF images
Lazy loading
Responsive images
Minimal unnecessary JavaScript
SEO-friendly HTML
Accessibility
Proper contrast
Keyboard navigation
Optimized mobile performance
Target a premium Lighthouse-level experience.
29. IMAGE DIRECTION
Do not use generic low-quality stock images.
Use premium industrial photography style:
Indian industrial environments
Modern factories
Warehouses
Trucks on weighbridges
Jewellery stores
Retail counters
Security monitoring rooms
Cash handling environments
Clean product photography
Product images should be presented on clean neutral backgrounds.
Use the uploaded VSOZONE logo throughout the website.
Use the uploaded founder photograph only in the leadership/about section.
30. BRAND EXPERIENCE
The first 5 seconds should communicate:
VSOZONE = Accuracy + Engineering + Technology + Trust
The website should feel comparable to the professionalism of a large technology company while remaining authentic to an Indian engineering business.
It should NOT feel like:
A local shop
A generic WordPress template
A simple brochure website
A basic weighing-machine dealer website
It should feel like:
“A next-generation industrial technology company.”
31. FINAL HOMEPAGE FLOW
Use this exact homepage storytelling sequence:
Premium Hero
Trust / Experience Strip
Explore Products
Featured Weighing Solutions
Industrial Weighbridge Showcase
Cash & Security Technology
Industries We Serve
Why VSOZONE
Service Ecosystem
Regional Presence
About VSOZONE
Founder — Veeresh Vishwanth
Future Technology / R&D
Enquiry CTA
Contact
Premium Footer
32. MOST IMPORTANT DESIGN INSTRUCTION
The website must look like a ₹10–50 crore technology/engineering brand, even if the current website is being launched as a first digital presence.
Think:
Industrial precision + premium technology + modern commerce + trustworthy Indian engineering.
Use the VSOZONE logo's deep green/teal + metallic gold + ivory identity consistently.
The final result should be:
Premium. Sophisticated. Trustworthy. Technical. Fast. Modern. Conversion-focused.
Do not copy Reliance Digital.
Take inspiration from its product discovery, category architecture and usability, while creating a completely original VSOZONE visual identity.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/40fc4d76-895c-4805-9959-f3d4946d20da).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
