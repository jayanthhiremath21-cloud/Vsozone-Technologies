import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import logoAsset from "@/assets/vsozone-logo.jpg.asset.json";

export const LOGO_URL = logoAsset.url;

export function Wordmark({
  className,
  tone = "dark",
}: {
  className?: string;
  tone?: "dark" | "light";
}) {
  return (
    <Link
      to="/"
      className={cn("group inline-flex items-center", className)}
      aria-label="VSOZONE Technologies — home"
    >
      <img
        src={LOGO_URL}
        alt="VSOZONE Technologies"
        className={cn(
          "h-11 w-auto max-w-[180px] object-contain transition-transform duration-300 group-hover:scale-[1.03] lg:h-14",
          tone === "light" ? "mix-blend-screen opacity-95" : "mix-blend-multiply",
        )}
      />
    </Link>
  );
}

export function LeafMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path d="M12 21V9" stroke="currentColor" className="text-gold" strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M12 12.5c-3.2 0-5-1.9-5-4.6 3.2 0 5 1.8 5 4.6ZM12 12.5c3.2 0 5-1.9 5-4.6-3.2 0-5 1.8-5 4.6ZM12 8.4c0-2.5 1.2-4.2 3-5.1.6 2.7-.6 4.6-3 5.1ZM12 8.4c0-2.5-1.2-4.2-3-5.1-.6 2.7.6 4.6 3 5.1Z"
        className="fill-gold-soft"
      />
      <path d="M4.5 14a7.6 7.6 0 0 0 15 0" stroke="currentColor" className="text-gold/70" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}
