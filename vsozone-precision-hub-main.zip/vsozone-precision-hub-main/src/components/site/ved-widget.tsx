import { useEffect, useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Send, X } from "lucide-react";
import { askVed } from "@/lib/ved.functions";
import { cn } from "@/lib/utils";

type VedMessage = { id: string; role: "user" | "assistant"; content: string };

const QUICK_ACTIONS = [
  "Find a product",
  "Check product availability",
  "Get product details",
  "Contact VSOZONE",
  "Help me choose a product",
];

export function VedWidget() {
  const ask = useServerFn(askVed);
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [pulse, setPulse] = useState(false);
  const [messages, setMessages] = useState<VedMessage[]>([
    {
      id: "intro",
      role: "assistant",
      content:
        "Hello! I'm VED, your VSOZONE AI assistant. Ask me about weighing machines, weighbridges, cash handling, CCTV or automation — or tell me what you need and I'll help you choose.",
    },
  ]);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) return;
    const id = setInterval(() => {
      setPulse(true);
      setTimeout(() => setPulse(false), 2400);
    }, 12000);
    return () => clearInterval(id);
  }, [open]);

  useEffect(() => {
    if (open) endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, open]);

  const sendMutation = useMutation({
    mutationFn: async (message: string) => {
      const history = messages
        .filter((m) => m.id !== "intro")
        .slice(-8)
        .map((m) => ({ role: m.role, content: m.content }));
      return ask({ data: { message, history } });
    },
    onSuccess: (res) =>
      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: "assistant", content: res.message },
      ]),
    onError: () =>
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content:
            "Sorry, I couldn't reach the assistant. Please try again or WhatsApp us on 9972607605.",
        },
      ]),
  });

  function send(text: string) {
    const message = text.trim();
    if (!message || sendMutation.isPending) return;
    setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: "user", content: message }]);
    setInput("");
    sendMutation.mutate(message);
  }

  return (
    <div className="relative">
      {/* Chat panel */}
      <div
        role="dialog"
        aria-label="VED — Your VSOZONE AI Assistant"
        aria-hidden={!open}
        className={cn(
          "absolute right-0 bottom-full mb-3 w-[min(22rem,calc(100vw-2rem))] origin-bottom-right overflow-hidden rounded-2xl border border-gold/25 bg-card shadow-[0_30px_70px_-30px_oklch(0.245_0.05_168/0.75)] transition-all duration-300 ease-out",
          open
            ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
            : "pointer-events-none translate-y-3 scale-95 opacity-0",
        )}
      >
        <div className="flex items-start justify-between gap-3 surface-deep px-4 py-3">
          <div className="flex min-w-0 items-center gap-3">
            <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gold/20 text-gold">
              <Sparkles className="size-5" />
            </span>
            <div className="min-w-0">
              <p className="truncate font-display text-base font-semibold text-deep-foreground">
                VED
              </p>
              <p className="truncate text-[0.7rem] text-deep-foreground/70">
                Your VSOZONE AI Assistant
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Close VED assistant"
            className="rounded-full p-1.5 text-deep-foreground/70 transition-colors hover:bg-gold/20 hover:text-gold"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="max-h-[45vh] min-h-[12rem] space-y-3 overflow-y-auto bg-background px-4 py-4">
          {messages.map((m) => (
            <div key={m.id} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={cn(
                  "max-w-[85%] rounded-xl px-3 py-2 text-sm leading-relaxed",
                  m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "border border-border bg-muted/50 text-foreground",
                )}
              >
                <p className="whitespace-pre-wrap">{m.content}</p>
              </div>
            </div>
          ))}
          {sendMutation.isPending ? (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Sparkles className="size-3.5 animate-pulse text-gold" /> VED is thinking…
            </div>
          ) : null}
          <div ref={endRef} />
        </div>

        <div className="flex flex-wrap gap-1.5 border-t border-border bg-background px-4 pt-3">
          {QUICK_ACTIONS.map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => send(q)}
              className="rounded-full border border-border px-2.5 py-1 text-[0.68rem] font-medium text-muted-foreground transition-colors hover:border-gold/60 hover:text-primary"
            >
              {q}
            </button>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex items-center gap-2 bg-background px-4 py-3"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            maxLength={1000}
            aria-label="Ask VED anything"
            placeholder="Ask VED anything…"
            className="h-10 min-w-0 flex-1 rounded-full border border-input bg-card px-4 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-gold/70"
          />
          <button
            type="submit"
            disabled={!input.trim() || sendMutation.isPending}
            aria-label="Send message to VED"
            className="grid size-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground transition-colors hover:bg-gold hover:text-gold-foreground disabled:opacity-50"
          >
            <Send className="size-4" />
          </button>
        </form>
      </div>

      {/* Launcher */}
      <div className="group relative flex justify-end">
        <span
          role="tooltip"
          className="pointer-events-none absolute right-0 bottom-full mb-2 hidden whitespace-nowrap rounded-lg surface-deep px-3 py-1.5 text-[0.7rem] font-medium opacity-0 shadow-lg transition-opacity duration-200 group-hover:opacity-100 lg:block"
        >
          Your VSOZONE AI Assistant
        </span>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label="Ask VED — your VSOZONE AI assistant"
          title="Your VSOZONE AI Assistant"
          className={cn(
            "inline-flex items-center gap-2 rounded-full border border-gold/40 py-3 pr-5 pl-4 font-display text-sm font-bold tracking-wide text-deep-foreground shadow-[0_18px_40px_-18px_oklch(0.245_0.05_168/0.85)] surface-deep transition-all duration-300 hover:scale-[1.04] hover:border-gold hover:shadow-[0_22px_50px_-18px_oklch(0.735_0.132_82/0.6)]",
            pulse && !open && "ved-pulse",
          )}
        >
          <Sparkles className="size-5 shrink-0 text-gold" />
          <span className="text-gold-gradient">VED</span>
          <span className="max-w-0 overflow-hidden whitespace-nowrap text-deep-foreground/85 opacity-0 transition-all duration-300 group-hover:max-w-[5rem] group-hover:opacity-100">
            <span className="pl-1">Ask VED</span>
          </span>
        </button>
      </div>
    </div>
  );
}
