import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, MessageCircle, Phone, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { COMPANY } from "@/lib/site-data";
import { Wordmark } from "./logo";
import { SearchDialog } from "./search-dialog";
import { useEnquiry } from "./enquiry";

const nav = [
  { label: "Home", to: "/" },
  { label: "Products", to: "/products" },
  { label: "Industries", to: "/industries" },
  { label: "Solutions", to: "/solutions" },
  { label: "Services", to: "/services" },
  { label: "About Us", to: "/about" },
  { label: "Resources", to: "/resources" },
  { label: "Contact", to: "/contact" },
] as const;

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { open: openEnquiry } = useEnquiry();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <div className="hidden bg-deep px-4 py-2 text-center text-xs font-medium tracking-wide text-deep-foreground/80 lg:block">
        <span className="text-gold">{COMPANY.tagline}</span>
        <span className="mx-3 text-deep-foreground/30">|</span>
        Weighing • Weighbridges • Cash Handling • Security • Automation
        <span className="mx-3 text-deep-foreground/30">|</span>
        <a href={COMPANY.phoneHref} className="hover:text-gold">
          {COMPANY.phone}
        </a>
      </div>

      <header
        className={`sticky top-0 z-50 border-b transition-all duration-300 ${
          scrolled
            ? "border-border bg-background/90 backdrop-blur-xl shadow-[0_10px_30px_-24px_oklch(0.245_0.05_168/0.6)]"
            : "border-transparent bg-background"
        }`}
      >
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 lg:px-6">
          <Wordmark className="min-w-0" />

          <div className="flex items-center gap-1.5 sm:gap-2">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Search"
              onClick={() => setSearchOpen(true)}
            >
              <Search />
            </Button>
            <Button variant="ghost" size="icon" aria-label="WhatsApp us" asChild>
              <a href={COMPANY.whatsappHref} target="_blank" rel="noopener noreferrer">
                <MessageCircle />
              </a>
            </Button>
            <Button
              className="hidden shrink-0 lg:inline-flex"
              onClick={() => openEnquiry("General enquiry")}
            >
              Get a Quote
            </Button>

            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="lg:hidden" aria-label="Open menu">
                  <Menu />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[86vw] max-w-sm surface-deep border-l-gold/20">
                <SheetTitle className="sr-only">Menu</SheetTitle>
                <div className="flex items-center justify-between p-5">
                  <Wordmark tone="light" />
                </div>
                <nav className="flex flex-col gap-1 px-4 pb-6">
                  {nav.map((item) => (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setMenuOpen(false)}
                      className="rounded-md px-3 py-3 text-base font-semibold text-deep-foreground/85 transition-colors hover:bg-deep-foreground/10 hover:text-gold"
                      activeProps={{ className: "text-gold" }}
                      activeOptions={{ exact: item.to === "/" }}
                    >
                      {item.label}
                    </Link>
                  ))}
                  <div className="mt-4 grid gap-2">
                    <Button
                      variant="gold"
                      size="lg"
                      onClick={() => {
                        setMenuOpen(false);
                        openEnquiry("General enquiry");
                      }}
                    >
                      Get a Quote
                    </Button>
                    <Button variant="outlineLight" size="lg" asChild>
                      <a href={COMPANY.phoneHref}>
                        <Phone /> Call {COMPANY.phone}
                      </a>
                    </Button>
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        <nav className="hidden border-t border-border/70 lg:block">
          <div className="mx-auto flex max-w-7xl items-center gap-1 px-6">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.to === "/" }}
                className="group relative px-3.5 py-3 text-sm font-semibold text-foreground/75 transition-colors hover:text-primary"
                activeProps={{ className: "text-primary" }}
              >
                {item.label}
                <span className="pointer-events-none absolute inset-x-3 bottom-0 h-[2px] scale-x-0 rounded-full bg-gold transition-transform duration-300 group-hover:scale-x-100 group-data-[status=active]:scale-x-100" />
              </Link>
            ))}
          </div>
        </nav>
      </header>

      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />
      <button
        type="button"
        onClick={() => setSearchOpen(true)}
        className="sr-only"
        aria-hidden
        tabIndex={-1}
      >
        <X className="hidden" />
      </button>
    </>
  );
}
