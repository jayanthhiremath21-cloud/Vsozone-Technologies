import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { images } from "@/lib/site-data";

// Campaign slides. Replace these URLs with the finished marketing artworks
// (why-vsozone-01..06) once they are uploaded — images are shown uncropped.
export const campaignSlides = [
  images.heroIndustrial,
  images.sceneIndustry,
  images.prodJewellery,
  images.prodCash,
  images.sceneSecurity,
  images.sceneJewellery,
];

export function WhyCarousel() {
  const [index, setIndex] = useState(0);
  const total = campaignSlides.length;
  const touchX = useRef<number | null>(null);

  const go = useCallback(
    (dir: number) => setIndex((i) => (i + dir + total) % total),
    [total],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") go(-1);
      if (e.key === "ArrowRight") go(1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go]);

  return (
    <div className="mt-12">
      <div
        className="relative overflow-hidden rounded-xl border border-gold/25 bg-ink/40 shadow-[0_30px_80px_-40px_rgba(0,0,0,0.65)]"
        onTouchStart={(e) => {
          touchX.current = e.touches[0]?.clientX ?? null;
        }}
        onTouchEnd={(e) => {
          const start = touchX.current;
          const end = e.changedTouches[0]?.clientX;
          if (start == null || end == null) return;
          if (Math.abs(end - start) > 45) go(end < start ? 1 : -1);
          touchX.current = null;
        }}
        aria-roledescription="carousel"
        aria-label="Why choose VSOZONE campaign"
      >
        <div
          className="flex transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {campaignSlides.map((src, i) => (
            <div
              key={src}
              className="w-full shrink-0"
              aria-hidden={i !== index}
              role="group"
              aria-label={`${String(i + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}`}
            >
              <img
                src={src}
                alt={`VSOZONE campaign slide ${i + 1}`}
                loading={i === 0 ? "eager" : "lazy"}
                className="mx-auto max-h-[70vh] w-full object-contain"
              />
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={() => go(-1)}
          aria-label="Previous slide"
          className="absolute top-1/2 left-3 grid size-11 -translate-y-1/2 place-items-center rounded-full border border-gold/40 bg-deep/70 text-gold backdrop-blur transition-colors hover:bg-deep"
        >
          <ChevronLeft className="size-5" />
        </button>
        <button
          type="button"
          onClick={() => go(1)}
          aria-label="Next slide"
          className="absolute top-1/2 right-3 grid size-11 -translate-y-1/2 place-items-center rounded-full border border-gold/40 bg-deep/70 text-gold backdrop-blur transition-colors hover:bg-deep"
        >
          <ChevronRight className="size-5" />
        </button>

        <span className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full border border-gold/30 bg-deep/80 px-4 py-1.5 text-xs font-bold tracking-[0.25em] text-gold backdrop-blur">
          {String(index + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}
        </span>
      </div>

      <div className="mt-6 flex flex-wrap justify-center gap-3">
        {campaignSlides.map((src, i) => (
          <button
            key={src}
            type="button"
            onClick={() => setIndex(i)}
            aria-label={`Go to slide ${i + 1}`}
            aria-current={i === index}
            className={cn(
              "h-16 w-24 overflow-hidden rounded-md border transition-all duration-300",
              i === index ? "border-gold opacity-100" : "border-deep-foreground/20 opacity-55 hover:opacity-90",
            )}
          >
            <img src={src} alt="" loading="lazy" className="size-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
