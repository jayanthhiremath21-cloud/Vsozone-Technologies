import { supabase } from "@/integrations/supabase/client";

/** Resolve a stored avatar_url into something an <img> can render.
 *  Google/OAuth avatars are absolute URLs; uploads are storage paths in the
 *  private "avatars" bucket and need a signed URL. */
export async function resolveAvatarUrl(value: string | null | undefined) {
  if (!value) return null;
  if (/^https?:\/\//i.test(value)) return value;
  const { data, error } = await supabase.storage.from("avatars").createSignedUrl(value, 3600);
  if (error) return null;
  return data.signedUrl;
}

export async function uploadAvatar(userId: string, file: File) {
  if (!file.type.startsWith("image/")) throw new Error("Please choose an image file.");
  if (file.size > 3 * 1024 * 1024) throw new Error("Image must be smaller than 3 MB.");
  const ext = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const path = `${userId}/avatar-${Date.now()}.${ext}`;
  const { error } = await supabase.storage
    .from("avatars")
    .upload(path, file, { upsert: true, contentType: file.type });
  if (error) throw error;
  return path;
}

export function initialsOf(name?: string | null, fallback = "VS") {
  const n = (name ?? "").trim();
  if (!n) return fallback;
  const parts = n.split(/\s+/).slice(0, 2);
  return parts.map((p) => p[0]?.toUpperCase() ?? "").join("") || fallback;
}
