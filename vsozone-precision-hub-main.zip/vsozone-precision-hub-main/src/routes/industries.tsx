import { createFileRoute } from "@tanstack/react-router";
import { industries } from "@/lib/site-data";
import { Section, SectionHead, IndustryExplorer, EnquiryCta } from "@/components/site/pieces";
import { Reveal } from "@/components/site/reveal";

export const Route = createFileRoute("/industries")({
  head: () => ({
    meta: [
      { title: "Industries We Serve — VSOZONE Technologies" },
      {
        name: "description",
        content:
          "Weighing, cash handling and security solutions for jewellery, manufacturing, logistics, agriculture, retail, warehousing and banking.",
      },
      { property: "og:title", content: "Industries We Serve — VSOZONE Technologies" },
      {
        property: "og:description",
        content: "Industry-specific weighing and technology solutions across Karnataka, Goa and Maharashtra.",
      },
    ],
  }),
  component: IndustriesPage,
});

function IndustriesPage() {
  return (
    <>
      <Section tone="muted">
        <SectionHead
          eyebrow="Industries"
          title="Solutions built around how your industry works"
          subtitle="From jewellery counters to weighbridge yards, our equipment is selected and configured for the realities of your operation."
        />
        <div className="mt-12">
          <IndustryExplorer />
        </div>
      </Section>

      <Section>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {industries.map((industry, i) => (
            <Reveal key={industry.name} delay={i * 40}>
              <article className="card-lift h-full rounded-xl border border-border bg-card p-6">
                <h3 className="text-base font-bold text-primary">{industry.name}</h3>
                <div aria-hidden className="mt-3 rule-gold opacity-70" />
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  {industry.description}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>
      <EnquiryCta />
    </>
  );
}
