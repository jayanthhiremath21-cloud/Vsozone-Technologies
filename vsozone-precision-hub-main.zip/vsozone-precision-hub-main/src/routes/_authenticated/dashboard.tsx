import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { CrmShell } from "@/components/crm/shell";
import { DEAL_STAGES, OPEN_STAGES, formatINR, type Contact, type Deal } from "@/lib/crm";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "CRM Dashboard — VSOZONE Technologies" },
      { name: "description", content: "Pipeline overview of your VSOZONE CRM contacts and deals." },
      { property: "og:title", content: "CRM Dashboard — VSOZONE Technologies" },
      { property: "og:description", content: "Your contacts, deals and pipeline at a glance." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { data: profile } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contacts")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Contact[];
    },
  });

  const { data: deals = [] } = useQuery({
    queryKey: ["deals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deals")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Deal[];
    },
  });

  const active = deals.filter((d) => OPEN_STAGES.includes(d.stage));
  const won = deals.filter((d) => d.stage === "Won");
  const lost = deals.filter((d) => d.stage === "Lost");
  const total = deals.reduce((sum, d) => sum + Number(d.value ?? 0), 0);

  return (
    <CrmShell
      title={`Welcome, ${profile?.display_name ?? "there"}`}
      description="Your VSOZONE CRM overview."
      actions={
        <Button asChild>
          <Link to="/assistant">Ask the AI Assistant</Link>
        </Button>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Stat label="Total Contacts" value={String(contacts.length)} />
        <Stat label="Active Deals" value={String(active.length)} />
        <Stat label="Won Deals" value={String(won.length)} />
        <Stat label="Lost Deals" value={String(lost.length)} />
        <Stat label="Total Deal Value" value={formatINR(total)} />
      </div>

      <section className="mt-10">
        <h2 className="text-lg font-bold text-primary">Pipeline</h2>
        <div className="mt-4 grid gap-3 overflow-x-auto lg:grid-cols-7">
          {DEAL_STAGES.map((stage) => {
            const items = deals.filter((d) => d.stage === stage);
            return (
              <div key={stage} className="rounded-lg border border-border bg-background p-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wide text-primary">{stage}</span>
                  <span className="text-xs text-muted-foreground">{items.length}</span>
                </div>
                <div aria-hidden className="mt-2 h-px bg-gold/40" />
                <ul className="mt-3 space-y-2">
                  {items.slice(0, 6).map((d) => (
                    <li key={d.id} className="rounded-md bg-muted/60 px-2.5 py-2 text-xs">
                      <p className="font-semibold text-foreground">{d.title}</p>
                      <p className="text-muted-foreground">{formatINR(d.value)}</p>
                    </li>
                  ))}
                  {items.length === 0 ? <li className="text-xs text-muted-foreground">—</li> : null}
                </ul>
              </div>
            );
          })}
        </div>
      </section>

      <div className="mt-10 grid gap-6 lg:grid-cols-2">
        <Panel title="Recent Contacts" to="/contacts">
          {contacts.slice(0, 5).map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
              <span className="font-semibold text-foreground">{c.name}</span>
              <span className="text-muted-foreground">{c.company ?? "—"}</span>
            </li>
          ))}
          {contacts.length === 0 ? <li className="py-3 text-sm text-muted-foreground">No contacts yet.</li> : null}
        </Panel>
        <Panel title="Recent Deals" to="/deals">
          {deals.slice(0, 5).map((d) => (
            <li key={d.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
              <span className="font-semibold text-foreground">{d.title}</span>
              <span className="text-muted-foreground">
                {d.stage} · {formatINR(d.value)}
              </span>
            </li>
          ))}
          {deals.length === 0 ? <li className="py-3 text-sm text-muted-foreground">No deals yet.</li> : null}
        </Panel>
      </div>
    </CrmShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-background p-5 shadow-sm">
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
      <p className="mt-2 text-2xl font-extrabold text-primary">{value}</p>
    </div>
  );
}

function Panel({
  title,
  to,
  children,
}: {
  title: string;
  to: "/contacts" | "/deals";
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border bg-background p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-primary">{title}</h2>
        <Link to={to} className="text-sm font-semibold text-gold hover:underline">
          View all
        </Link>
      </div>
      <ul className="mt-2 divide-y divide-border">{children}</ul>
    </div>
  );
}
