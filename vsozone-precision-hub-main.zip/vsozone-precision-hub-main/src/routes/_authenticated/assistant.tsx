import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Send, Sparkles } from "lucide-react";
import { CrmShell } from "@/components/crm/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { askAssistant, runCrmAction, type CrmAction } from "@/lib/assistant.functions";

export const Route = createFileRoute("/_authenticated/assistant")({
  head: () => ({
    meta: [
      { title: "AI Assistant — VSOZONE CRM" },
      { name: "description", content: "Manage contacts and deals with plain-English commands." },
      { property: "og:title", content: "AI Assistant — VSOZONE CRM" },
      { property: "og:description", content: "Manage contacts and deals with plain-English commands." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AssistantPage,
});

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  summary?: string[];
  action?: CrmAction;
  done?: boolean;
};

const SUGGESTIONS = [
  "Add Rahul Sharma from Kalaburagi as a contact",
  "Create a 1.5 lakh deal for weighbridge with Rahul",
  "Move the weighbridge deal to negotiation",
  "Show my open deals",
];

function AssistantPage() {
  const queryClient = useQueryClient();
  const ask = useServerFn(askAssistant);
  const run = useServerFn(runCrmAction);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "intro",
      role: "assistant",
      content:
        "Hi! Tell me what to do in plain English — add a contact, create a deal, move a deal to a new stage, or ask about your pipeline.",
    },
  ]);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages]);

  const sendMutation = useMutation({
    mutationFn: async (message: string) => {
      const history = messages
        .filter((m) => m.id !== "intro")
        .slice(-8)
        .map((m) => ({ role: m.role, content: m.content }));
      return ask({ data: { message, history } });
    },
    onSuccess: (result) => {
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: result.message,
          ...(result.kind === "proposal" ? { summary: result.summary, action: result.action } : {}),
        },
      ]);
    },
    onError: () => toast.error("The assistant could not respond. Please try again."),
  });

  const confirmMutation = useMutation({
    mutationFn: async ({ action }: { id: string; action: CrmAction }) => run({ data: action }),
    onSuccess: (res, variables) => {
      setMessages((prev) =>
        prev.map((m) => (m.id === variables.id ? { ...m, done: true } : m)).concat({
          id: crypto.randomUUID(),
          role: "assistant",
          content: res.message,
        }),
      );
      queryClient.invalidateQueries();
    },
    onError: (e: unknown) =>
      toast.error(e instanceof Error ? e.message : "Could not complete that action."),
  });

  function send(text: string) {
    const message = text.trim();
    if (!message || sendMutation.isPending) return;
    setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: "user", content: message }]);
    setInput("");
    sendMutation.mutate(message);
  }

  return (
    <CrmShell title="AI Assistant" description="Turn plain English into CRM actions — you always confirm first.">
      <div className="mx-auto flex max-w-3xl flex-col gap-4">
        <div className="min-h-[45vh] space-y-4 rounded-xl border border-border bg-background p-4 lg:p-6">
          {messages.map((m) => (
            <div key={m.id} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={`max-w-[85%] rounded-xl px-4 py-3 text-sm ${
                  m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "border border-border bg-muted/40 text-foreground"
                }`}
              >
                <p className="whitespace-pre-wrap">{m.content}</p>
                {m.summary?.length ? (
                  <ul className="mt-2 space-y-1 rounded-lg bg-background/70 p-3 text-xs text-muted-foreground">
                    {m.summary.map((s) => (
                      <li key={s}>• {s}</li>
                    ))}
                  </ul>
                ) : null}
                {m.action && !m.done ? (
                  <div className="mt-3 flex gap-2">
                    <Button
                      size="sm"
                      disabled={confirmMutation.isPending}
                      onClick={() => confirmMutation.mutate({ id: m.id, action: m.action as CrmAction })}
                    >
                      Confirm
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setMessages((prev) =>
                          prev.map((x) => (x.id === m.id ? { ...x, done: true } : x)).concat({
                            id: crypto.randomUUID(),
                            role: "assistant",
                            content: "Okay, cancelled. Nothing was changed.",
                          }),
                        )
                      }
                    >
                      Cancel
                    </Button>
                  </div>
                ) : null}
              </div>
            </div>
          ))}
          {sendMutation.isPending ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Sparkles className="size-4 animate-pulse text-gold" /> Thinking…
            </div>
          ) : null}
          <div ref={endRef} />
        </div>

        <div className="flex flex-wrap gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => send(s)}
              className="rounded-full border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-gold/60 hover:text-primary"
            >
              {s}
            </button>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex gap-2"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="e.g. Add Rahul Sharma, Sharma Traders, Kalaburagi"
            maxLength={1000}
          />
          <Button type="submit" disabled={sendMutation.isPending || !input.trim()}>
            <Send className="size-4" />
          </Button>
        </form>
      </div>
    </CrmShell>
  );
}
