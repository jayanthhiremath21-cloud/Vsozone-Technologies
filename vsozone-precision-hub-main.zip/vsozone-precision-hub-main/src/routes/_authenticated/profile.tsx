import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { CrmShell } from "@/components/crm/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserAvatar } from "@/components/site/user-avatar";
import { uploadAvatar } from "@/lib/avatar";
import { useProfile } from "@/hooks/use-auth";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "My Profile — VSOZONE Technologies" },
      { name: "description", content: "Manage your VSOZONE Technologies account details." },
      { property: "og:title", content: "My Profile — VSOZONE Technologies" },
      { property: "og:description", content: "Manage your VSOZONE Technologies account details." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const queryClient = useQueryClient();
  const { data: profile, isLoading } = useProfile();
  const [fullName, setFullName] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name ?? "");
      setDisplayName(profile.display_name ?? "");
      setUsername(profile.username ?? "");
    }
  }, [profile]);

  const save = useMutation({
    mutationFn: async () => {
      if (!profile) throw new Error("Profile not loaded yet.");
      const nextUsername = username.trim();
      if (nextUsername && nextUsername !== (profile.username ?? "")) {
        if (!/^[a-zA-Z0-9._-]{3,30}$/.test(nextUsername)) {
          throw new Error("Username must be 3-30 characters (letters, numbers, . _ -).");
        }
        const { data: available } = await supabase.rpc("is_username_available", {
          _username: nextUsername,
        });
        if (!available) throw new Error("That username is already taken.");
      }

      let avatarPath = profile.avatar_url;
      if (photo) avatarPath = await uploadAvatar(profile.id, photo);

      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: fullName.trim() || null,
          display_name: displayName.trim() || fullName.trim() || null,
          username: nextUsername || null,
          avatar_url: avatarPath,
        })
        .eq("id", profile.id);
      if (error) throw error;
    },
    onSuccess: () => {
      setPhoto(null);
      toast.success("Profile updated.");
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (e: unknown) =>
      toast.error(e instanceof Error ? e.message : "Could not save profile."),
  });

  const changePassword = useMutation({
    mutationFn: async () => {
      if (newPassword.length < 8) throw new Error("New password must be at least 8 characters.");
      if (newPassword !== confirmPassword) throw new Error("New passwords do not match.");
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
        ...(currentPassword ? { current_password: currentPassword } : {}),
      } as Parameters<typeof supabase.auth.updateUser>[0]);
      if (error) throw error;
    },
    onSuccess: () => {
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      toast.success("Password changed.");
    },
    onError: (e: unknown) =>
      toast.error(e instanceof Error ? e.message : "Could not change password."),
  });

  const resetPassword = useMutation({
    mutationFn: async () => {
      if (!profile?.email) throw new Error("No email on file.");
      const { error } = await supabase.auth.resetPasswordForEmail(profile.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
    },
    onSuccess: () => toast.success("Password reset link sent to your email."),
    onError: (e: unknown) =>
      toast.error(e instanceof Error ? e.message : "Could not send reset email."),
  });

  return (
    <CrmShell title="My Profile" description="Your VSOZONE account details.">
      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
          <div className="space-y-5 rounded-xl border border-border bg-background p-5 lg:p-6">
            <div className="flex items-center gap-4">
              <UserAvatar
                src={profile?.avatar_url}
                name={profile?.full_name ?? profile?.display_name}
                className="size-16 text-base"
              />
              <div className="min-w-0">
                <p className="truncate font-semibold text-primary">
                  {profile?.full_name || profile?.display_name || "VSOZONE Customer"}
                </p>
                <p className="truncate text-xs text-muted-foreground">
                  @{profile?.username ?? "no-username"} ·{" "}
                  {profile?.auth_provider === "google" ? "Google account" : "Email account"}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Member since{" "}
                  {profile?.created_at
                    ? new Date(profile.created_at).toLocaleDateString("en-IN", {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                      })
                    : "—"}
                </p>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Email</Label>
              <Input value={profile?.email ?? ""} readOnly disabled />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="full_name">Full name</Label>
              <Input id="full_name" value={fullName} maxLength={80} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="display_name">Display name</Label>
              <Input id="display_name" value={displayName} maxLength={80} onChange={(e) => setDisplayName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="username">Username</Label>
              <Input id="username" value={username} maxLength={30} onChange={(e) => setUsername(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Profile photo</Label>
              <div className="flex items-center gap-3">
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
                />
                <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                  Choose photo
                </Button>
                <span className="truncate text-xs text-muted-foreground">
                  {photo ? photo.name : "No new file selected"}
                </span>
              </div>
            </div>
            <Button onClick={() => save.mutate()} disabled={save.isPending}>
              {save.isPending ? "Saving…" : "Save changes"}
            </Button>
          </div>

          <div className="space-y-5 rounded-xl border border-border bg-background p-5 lg:p-6">
            <div>
              <h2 className="font-semibold text-primary">Change password</h2>
              <p className="text-xs text-muted-foreground">
                Keep your account secure with a strong, unique password.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="current_password">Current password</Label>
              <Input
                id="current_password"
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                autoComplete="current-password"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="new_password">New password</Label>
              <Input
                id="new_password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                autoComplete="new-password"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="confirm_password">Confirm new password</Label>
              <Input
                id="confirm_password"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                autoComplete="new-password"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => changePassword.mutate()} disabled={changePassword.isPending}>
                {changePassword.isPending ? "Updating…" : "Change password"}
              </Button>
              <Button variant="outline" onClick={() => resetPassword.mutate()} disabled={resetPassword.isPending}>
                Email me a reset link
              </Button>
            </div>
          </div>
        </div>
      )}
    </CrmShell>
  );
}
