import { createFileRoute } from "@tanstack/react-router";
import { MapPin, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { COMPANY } from "@/lib/site-data";
import { Section, SectionHead } from "@/components/site/pieces";
import { useEnquiry } from "@/components/site/enquiry";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact VSOZONE Technologies — Kalaburagi, Karnataka" },
      {
        name: "description",
        content:
          "Call 9972607605 or WhatsApp VSOZONE Technologies in Kalaburagi, Karnataka for weighing, weighbridge, cash handling and security enquiries.",
      },
      { property: "og:title", content: "Contact VSOZONE Technologies" },
      {
        property: "og:description",
        content: "Talk to our team about equipment selection, installation and AMC.",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const { open } = useEnquiry();

  return (
    <Section tone="muted">
      <SectionHead
        eyebrow="Contact"
        title="Talk to our engineering team"
        subtitle="Share your requirement — capacity, location and application — and we'll recommend the right solution."
      />

      <div className="mt-12 grid gap-6 lg:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-6">
          <MapPin className="size-5 text-gold" />
          <h3 className="mt-4 text-base font-bold text-primary">Head Office</h3>
          <address className="mt-3 space-y-0.5 text-sm not-italic leading-relaxed text-muted-foreground">
            {COMPANY.address.map((line) => (
              <div key={line}>{line}</div>
            ))}
          </address>
        </div>

        <div className="rounded-xl border border-border bg-card p-6">
          <Phone className="size-5 text-gold" />
          <h3 className="mt-4 text-base font-bold text-primary">Call Us</h3>
          <a
            href={COMPANY.phoneHref}
            className="mt-3 block text-lg font-semibold text-foreground hover:text-gold"
          >
            {COMPANY.phone}
          </a>
          <p className="mt-2 text-sm text-muted-foreground">Mon – Sat, business hours</p>
        </div>

        <div className="rounded-xl border border-border bg-card p-6">
          <MessageCircle className="size-5 text-gold" />
          <h3 className="mt-4 text-base font-bold text-primary">WhatsApp</h3>
          <p className="mt-3 text-sm text-muted-foreground">
            Fastest way to share requirements, photos and site details.
          </p>
          <div className="mt-5 grid gap-2">
            <Button asChild>
              <a href={COMPANY.whatsappHref} target="_blank" rel="noopener noreferrer">
                Chat on WhatsApp
              </a>
            </Button>
            <Button variant="outlineGold" onClick={() => open("General enquiry")}>
              Send an Enquiry
            </Button>
          </div>
        </div>
      </div>
    </Section>
  );
}
