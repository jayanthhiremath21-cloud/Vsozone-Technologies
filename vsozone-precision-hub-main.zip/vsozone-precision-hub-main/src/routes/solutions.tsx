import { createFileRoute } from "@tanstack/react-router";
import { categories } from "@/lib/site-data";
import { Section, SectionHead, CategoryCard, EnquiryCta } from "@/components/site/pieces";

export const Route = createFileRoute("/solutions")({
  head: () => ({
    meta: [
      { title: "Solutions — Weighing, Cash Handling, Security & Automation | VSOZONE" },
      {
        name: "description",
        content:
          "Five solution categories: weighing machines, electronic weighbridges, cash counting and billing, security systems, automation and services.",
      },
      { property: "og:title", content: "VSOZONE Solutions — Weighing, Cash, Security, Automation" },
      {
        property: "og:description",
        content: "Complete solution categories with installation, commissioning, AMC and spare parts support.",
      },
    ],
  }),
  component: SolutionsPage,
});

function SolutionsPage() {
  return (
    <>
      <Section tone="muted">
        <SectionHead
          eyebrow="Solutions"
          title="Five solution families, one accountable partner"
          subtitle="Every solution includes consultation, correct capacity selection, installation, commissioning and long-term service."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c, i) => (
            <CategoryCard key={c.slug} category={c} delay={i * 50} />
          ))}
        </div>
      </Section>
      <EnquiryCta />
    </>
  );
}
