import { createFileRoute } from "@tanstack/react-router";
import { COMPANY, timeline, whyVsozone } from "@/lib/site-data";
import { Section, SectionHead, EnquiryCta } from "@/components/site/pieces";
import { Reveal } from "@/components/site/reveal";

const founder = "/__l5e/assets-v1/9d0236a2-0a0f-4335-be9c-285bdd886f4e/founder-veeresh.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About VSOZONE Technologies — Engineering Since 2002" },
      {
        name: "description",
        content:
          "Founded in 2002 in Kalaburagi, Karnataka, VSOZONE Technologies delivers precision weighing, cash handling, security and automation solutions under founder Veeresh Vishwanth.",
      },
      { property: "og:title", content: "About VSOZONE Technologies — Engineering Since 2002" },
      {
        property: "og:description",
        content: "Our story, leadership, milestones and engineering approach.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <Section tone="muted">
        <SectionHead
          eyebrow={`Established ${COMPANY.established}`}
          title="An Indian engineering and technology company built on accuracy"
          subtitle={`${COMPANY.legalName} has served industries across North Karnataka since ${COMPANY.established}, combining precision equipment with dependable engineering support.`}
        />
      </Section>

      <Section>
        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <Reveal>
            <div className="overflow-hidden rounded-xl border border-border bg-card">
              <img
                src={founder}
                alt="Veeresh Vishwanth, Founder of VSOZONE Technologies"
                className="aspect-[4/5] w-full object-cover"
              />
            </div>
          </Reveal>
          <Reveal delay={80}>
            <p className="eyebrow">Founder & Leadership</p>
            <h2 className="mt-3 text-3xl font-extrabold text-primary sm:text-4xl">
              Veeresh Vishwanth
            </h2>
            <div aria-hidden className="mt-5 rule-gold" />
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              Under the leadership of founder Veeresh Vishwanth, VSOZONE Technologies has grown from
              a weighing equipment specialist into a broader engineering and technology partner —
              covering weighbridges, cash handling, billing, security systems and automation.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              The approach has stayed consistent: understand the customer's operation, recommend the
              right capacity and configuration, install it properly, and support it for the long term.
            </p>
            <p className="mt-6 text-lg font-semibold text-gold">“{COMPANY.tagline}”</p>
          </Reveal>
        </div>
      </Section>

      <Section tone="muted">
        <SectionHead eyebrow="Milestones" title="Our journey" />
        <ol className="mt-12 space-y-6 border-l-2 border-gold/30 pl-6">
          {timeline.map((t, i) => (
            <Reveal key={t.label} delay={i * 60}>
              <li className="relative">
                <span
                  aria-hidden
                  className="absolute -left-[1.9rem] top-2 size-3 rounded-full bg-gold ring-4 ring-secondary"
                />
                <span className="text-xs font-bold uppercase tracking-[0.18em] text-gold">
                  {t.label}
                </span>
                <h3 className="mt-1 text-lg font-bold text-primary">{t.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{t.description}</p>
              </li>
            </Reveal>
          ))}
        </ol>
      </Section>

      <Section>
        <SectionHead
          eyebrow="Why VSOZONE"
          title="Engineering, research and long-term partnership"
          subtitle="We invest in product knowledge and service capability so accuracy is maintained well after installation."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {whyVsozone.map((w, i) => (
            <Reveal key={w.title} delay={i * 40}>
              <article className="card-lift h-full rounded-xl border border-border bg-card p-6">
                <h3 className="text-base font-bold text-primary">{w.title}</h3>
                <div aria-hidden className="mt-3 rule-gold opacity-70" />
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{w.description}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </Section>
      <EnquiryCta />
    </>
  );
}
